package com.example.yuva.myrecipie;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.example.yuva.myrecipie.data.Ingredient;
import com.example.yuva.myrecipie.data.Step;
import com.example.yuva.myrecipie.fragment.IngreFragment;
import com.example.yuva.myrecipie.fragment.StepsFragment;

import java.util.List;

public class DetailActivity extends AppCompatActivity {
    List<Step> step;
    List<Ingredient> ingredients;
    boolean twoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        step = getIntent().getParcelableArrayListExtra("steps");
        ingredients = getIntent().getParcelableArrayListExtra("ingredients");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (findViewById(R.id.tablet) != null)
            twoPane = true;
        else
            twoPane = false;
        FragmentManager fm = getSupportFragmentManager();
        FragmentManager fm1 = getSupportFragmentManager();
        IngreFragment ingreFragment = new IngreFragment();
        StepsFragment stepsFragment = new StepsFragment();
        stepsFragment.setStep(step, twoPane);
        //stepsFragment.setStep(step,fm);
        ingreFragment.setIngre(ingredients);
        fm.beginTransaction().add(R.id.steps_layout, stepsFragment).commit();
        fm1.beginTransaction().add(R.id.ingredient_layout, ingreFragment).commit();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            onBackPressed();
        return super.onOptionsItemSelected(item);
    }
}
