package com.example.yuva.myrecipie;

import android.content.Context;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.yuva.myrecipie.data.Step;
import com.example.yuva.myrecipie.fragment.VideoFragment;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

import java.util.List;

public class VideoActivity extends AppCompatActivity {
    List<Step> stepList;
    int position;
    VideoFragment videoFragment;
    Button next, previous;
    long playBackPosition;

    @NonNull
    public static ExoPlayer getSimpleExoPlayer(Context context) {
        BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
        TrackSelection.Factory videoTrackSelectionFactory = new AdaptiveTrackSelection.Factory(bandwidthMeter);
        DefaultTrackSelector trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);
        return ExoPlayerFactory.newSimpleInstance(context, trackSelector);
    }

    @NonNull
    public static MediaSource getMediaSource(Context context, Uri videoUri) {
        DefaultBandwidthMeter bandwidthMeter1 = new DefaultBandwidthMeter();
        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(context, Util.getUserAgent(context, "Baking"), bandwidthMeter1);
        return new ExtractorMediaSource.Factory(dataSourceFactory).createMediaSource(videoUri);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        stepList = getIntent().getParcelableArrayListExtra("stepsvideo");
        position = getIntent().getIntExtra("position", 0);
        FragmentManager fm = getSupportFragmentManager();
        videoFragment = new VideoFragment();
        if (savedInstanceState != null) {
            position = savedInstanceState.getInt("p");
            playBackPosition = savedInstanceState.getLong("pos");
            Step step = stepList.get(position);
            videoFragment.setDescription(step.getDescription());
            videoFragment.playbackPosition = playBackPosition;
            if (!step.getVideoURL().isEmpty() && step.getThumbnailURL().isEmpty()) {
                videoFragment.setVideoUri(Uri.parse(step.getVideoURL()));
            } else
                videoFragment.setVideoUri(Uri.parse(step.getThumbnailURL()));
            fm.beginTransaction().replace(R.id.holder, videoFragment).commit();

        } else {
            Step step = stepList.get(position);
            videoFragment.setDescription(step.getDescription());
            if (!step.getVideoURL().isEmpty() && step.getThumbnailURL().isEmpty()) {
                videoFragment.setVideoUri(Uri.parse(step.getVideoURL()));
            } else
                videoFragment.setVideoUri(Uri.parse(step.getThumbnailURL()));
            fm.beginTransaction().replace(R.id.holder, videoFragment).commit();
        }

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            next = findViewById(R.id.next);
            previous = findViewById(R.id.previous);
            setTheme(R.style.AppTheme);
            if (position == 0)
                previous.setVisibility(View.INVISIBLE);
            if (position == stepList.size() - 1)
                next.setVisibility(View.INVISIBLE);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    position = position + 1;
                    previous.setVisibility(View.VISIBLE);
                    if (position == stepList.size() - 1) {
                        next.setVisibility(View.INVISIBLE);
                    }
                    updateUI();
                }
            });
            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    position = position - 1;
                    next.setVisibility(View.VISIBLE);
                    if (position == 0) {
                        previous.setVisibility(View.INVISIBLE);
                    }
                    updateUI();
                }
            });
        }

    }

    @Override
    public void onStart() {
        super.onStart();
        if (Util.SDK_INT > 23) {
            videoFragment.setUpPlayer(Uri.parse(stepList.get(position).getVideoURL()));
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Util.SDK_INT <= 23) {
            videoFragment.setUpPlayer(Uri.parse(stepList.get(position).getVideoURL()));
        }
    }

    private void updateUI() {
        Step step = stepList.get(position);
        videoFragment.desc_tv.setText(step.getDescription());
        if (!step.getVideoURL().isEmpty() && step.getThumbnailURL().isEmpty())
            videoFragment.setVideoUri(Uri.parse(step.getVideoURL()));
        else
            videoFragment.setVideoUri(Uri.parse(step.getThumbnailURL()));
        if (step.getVideoURL().isEmpty()) {
            videoFragment.simpleExoPlayerView.setUseArtwork(true);
            //videoFragment.simpleExoPlayerView.setDefaultArtwork(BitmapFactory.decodeResource(getResources(),R.drawable.no_video_err_img));
            videoFragment.simpleExoPlayerView.setVisibility(View.GONE);
            videoFragment.video_err_img.setVisibility(View.VISIBLE);
            videoFragment.exoPlayer.stop();
        } else {
            videoFragment.simpleExoPlayerView.setVisibility(View.VISIBLE);
            videoFragment.video_err_img.setVisibility(View.GONE);
            videoFragment.simpleExoPlayerView.setPlayer(videoFragment.exoPlayer);
            videoFragment.exoPlayer.setPlayWhenReady(videoFragment.playWhenReady);
            videoFragment.exoPlayer.seekTo(playBackPosition);
            videoFragment.exoPlayer.prepare(getMediaSource(this, Uri.parse(step.getVideoURL())));
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (Util.SDK_INT <= 23) {
            videoFragment.releasePlayer();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (Util.SDK_INT > 23) {
            videoFragment.releasePlayer();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            onBackPressed();
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i("pos", "onSaveInstanceState:" + position);
        outState.putInt("p", position);
        outState.putLong("pos", videoFragment.exoPlayer.getContentPosition());
    }
}
