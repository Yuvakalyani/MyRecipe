package com.example.yuva.myrecipie.fragment;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.yuva.myrecipie.adapter.IngredientAdapter;
import com.example.yuva.myrecipie.data.Ingredient;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class IngreFragment extends Fragment {


    RecyclerView rv;
    List<Ingredient> ingredients;

    public IngreFragment() {

    }

    public void setIngre(List<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (savedInstanceState != null) {
            ingredients = savedInstanceState.getParcelableArrayList("ingreArrayList");
        }
        View v = inflater.inflate(R.layout.fragment_ingre, container, false);
        rv = v.findViewById(R.id.rec1);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(new IngredientAdapter(getContext(), ingredients));
        //Log.i(TAG, "onCreateView: "+ingredients.get(0).getIngredient());
        rv.setHasFixedSize(true);
        return v;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        ArrayList<Ingredient> ingreArrayList = new ArrayList<>(ingredients);
        outState.putParcelableArrayList("ingreArrayList", ingreArrayList);
    }
}
