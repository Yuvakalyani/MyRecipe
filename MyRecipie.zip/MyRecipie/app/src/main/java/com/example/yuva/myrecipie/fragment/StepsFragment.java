package com.example.yuva.myrecipie.fragment;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.yuva.myrecipie.VideoActivity;
import com.example.yuva.myrecipie.adapter.StepAdapter;
import com.example.yuva.myrecipie.data.Step;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class StepsFragment extends Fragment implements StepAdapter.ClickListener {
    RecyclerView rv;
    List<Step> step;
    boolean pane;
    FragmentManager fm;

    public StepsFragment() {
        // Required empty public constructor
    }
   /* public void setStep(List<Step> step, FragmentManager fm) {
        this.step = step;
        this.fm = fm;
    }*/

    public void setStep(List<Step> step, boolean twoPane) {
        this.step = step;
        this.pane = twoPane;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            step = savedInstanceState.getParcelableArrayList("stepArrayList");
            pane = savedInstanceState.getBoolean("twopane");
        }
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_steps, container, false);
        rv = v.findViewById(R.id.rec);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(new StepAdapter(getContext(), step, this));
        rv.setHasFixedSize(true);
        return v;

    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        ArrayList<Step> stepArrayList = new ArrayList<>(step);
        outState.putBoolean("twopane", pane);
        outState.putParcelableArrayList("stepArrayList", stepArrayList);
    }

    @Override
    public void onClickListener(int position) {
        ArrayList<Step> stepArrayList = new ArrayList<>(step);
        if (!pane) {
            Intent i2 = new Intent(getContext(), VideoActivity.class);
            i2.putExtra("stepsvideo", stepArrayList);
            i2.putExtra("position", position);
            getContext().startActivity(i2);

        } else {
            Log.i("TWO", "PANE");
            fm = getActivity().getSupportFragmentManager();
            VideoFragment videoFragment = new VideoFragment();
            videoFragment.setDescription(step.get(position).getDescription());
            videoFragment.setVideoUri(Uri.parse(step.get(position).getVideoURL()));
            fm.beginTransaction().replace(R.id.videoTabHolder, videoFragment).commit();
        }
    }
}
