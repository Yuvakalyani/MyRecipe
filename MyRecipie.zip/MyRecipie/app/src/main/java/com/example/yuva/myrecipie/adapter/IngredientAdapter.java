package com.example.yuva.myrecipie.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.yuva.myrecipie.data.Ingredient;

import java.util.List;

public class IngredientAdapter extends RecyclerView.Adapter<IngredientAdapter.IngreHolder> {
    Context c;
    List<Ingredient> ingredients;

    public IngredientAdapter(Context context, List<Ingredient> ingredients) {
        this.c=context;
        this.ingredients=ingredients;
    }

    @NonNull
    @Override
    public IngreHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(c).inflate(R.layout.ingredientsitem,parent,false);
        return new IngreHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull IngreHolder holder, int position) {
        holder.quantity.setText(String.valueOf(ingredients.get(position).getQuantity()));
        holder.measure.setText(String.valueOf(ingredients.get(position).getMeasure()));
        holder.ingredient.setText(ingredients.get(position).getIngredient());
    }

    @Override
    public int getItemCount() {
        return ingredients.size();
    }

    public class IngreHolder extends RecyclerView.ViewHolder {
        TextView quantity,measure,ingredient;
        public IngreHolder(View itemView) {
            super(itemView);
            quantity=itemView.findViewById(R.id.quantity);
            measure=itemView.findViewById(R.id.measure);
            ingredient=itemView.findViewById(R.id.ingredient);

        }
    }
}