package com.example.yuva.myrecipie.servicepath;

import com.example.yuva.myrecipie.data.JsonRecipe;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RetrofitPath {
    @GET("baking.json")
    Call<List<JsonRecipe>> getRecipes();
}
