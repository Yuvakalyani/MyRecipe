package com.example.yuva.myrecipie.fragment;


import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.yuva.myrecipie.VideoActivity;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.util.Util;

import static android.view.View.GONE;

/**
 * A simple {@link Fragment} subclass.
 */
public class VideoFragment extends Fragment {
    public SimpleExoPlayerView simpleExoPlayerView;
    public TextView desc_tv;
    public ExoPlayer exoPlayer;
    public ImageView video_err_img;
    public long playbackPosition;
    public boolean playWhenReady;
    String description;
    Uri videoUri;
    int curr_window;


    public VideoFragment() {
        // Required empty public constructor
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setVideoUri(Uri videoUri) {
        this.videoUri = videoUri;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_video, container, false);
        simpleExoPlayerView = v.findViewById(R.id.exo_player);
        desc_tv = v.findViewById(R.id.videoText);
        video_err_img = v.findViewById(R.id.no_video_error_img);
        simpleExoPlayerView.setControllerHideOnTouch(true);
        if (savedInstanceState != null) {
            description = savedInstanceState.getString("description");
            videoUri = savedInstanceState.getParcelable("uri");
            playbackPosition = savedInstanceState.getLong("position");
            curr_window = savedInstanceState.getInt("window");
            playWhenReady = savedInstanceState.getBoolean("ready");

        }
        simpleExoPlayerView.setUseArtwork(true);
        if (v.findViewById(R.id.tab_desc) == null) {
            if (getContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                desc_tv.setVisibility(GONE);
                ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
            } else {
                desc_tv.setVisibility(View.VISIBLE);
                desc_tv.setText(description);
                simpleExoPlayerView.setLayoutParams(new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 700));
                ((AppCompatActivity) getActivity()).getSupportActionBar().show();
            }
        } else {
            desc_tv.setVisibility(View.VISIBLE);
            desc_tv.setText(description);
        }
        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        if (Util.SDK_INT > 23) {
            setUpPlayer(videoUri);
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        if ((Util.SDK_INT <= 23 || exoPlayer == null)) {
            setUpPlayer(videoUri);
        }
    }

    public void setUpPlayer(Uri videoUri) {
        if (exoPlayer == null) {
            exoPlayer = VideoActivity.getSimpleExoPlayer(getContext());
            if (videoUri.toString().isEmpty()) {
                simpleExoPlayerView.setVisibility(GONE);
                video_err_img.setVisibility(View.VISIBLE);
                exoPlayer.stop();
            } else {
                simpleExoPlayerView.setVisibility(View.VISIBLE);
                video_err_img.setVisibility(GONE);
                MediaSource mediaSource = VideoActivity.getMediaSource(getContext(), videoUri);
                exoPlayer.prepare(mediaSource);
                simpleExoPlayerView.setPlayer(exoPlayer);
                exoPlayer.setPlayWhenReady(playWhenReady);
                exoPlayer.seekTo(playbackPosition);
            }
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        if (Util.SDK_INT <= 23) {
            releasePlayer();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (Util.SDK_INT > 23) {
            releasePlayer();
        }
    }

    public void releasePlayer() {
        playbackPosition = exoPlayer.getContentPosition();
        curr_window = exoPlayer.getCurrentWindowIndex();
        playWhenReady = exoPlayer.getPlayWhenReady();
        exoPlayer.release();
        //exoPlayer = null;
    }




   /*
    if(v.findViewById(R.id.fragvideoland)!=null){
        }
        else {
            tv = v.findViewById(R.id.videoText);
            previous = v.findViewById(R.id.previous);
            next = v.findViewById(R.id.next);
            tv.setText(steps.get(position).getDescription());
            if (position != 0) {
                previous.setVisibility(View.VISIBLE);
            } else
                previous.setVisibility(View.GONE);
            if (position != steps.size() - 1) {
                next.setVisibility(View.VISIBLE);
            } else
                next.setVisibility(View.GONE);

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    previous.setVisibility(View.VISIBLE);
                    if (position == steps.size() - 2) {
                        next.setVisibility(View.INVISIBLE);
                        position = position + 1;
                        player.prepare(getMediaSource(getContext(), Uri.parse(steps.get(position).getVideoURL())));
                        tv.setText(steps.get(position).getDescription());
                    } else {
                        position = position + 1;
                        player.prepare(getMediaSource(getContext(), Uri.parse(steps.get(position).getVideoURL())));
                        tv.setText(steps.get(position).getDescription());
                    }
                    VideoCheck(steps.get(position).getVideoURL());
                }
            });
            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    next.setVisibility(View.VISIBLE);
                    if (position == 1) {
                        previous.setVisibility(View.INVISIBLE);
                        position = position - 1;
                        player.prepare(getMediaSource(getContext(), Uri.parse(steps.get(position).getVideoURL())));
                        tv.setText(steps.get(position).getDescription());
                    } else {
                        position = position - 1;
                        player.prepare(getMediaSource(getContext(), Uri.parse(steps.get(position).getVideoURL())));
                        tv.setText(steps.get(position).getDescription());
                    }
                    VideoCheck(steps.get(position).getVideoURL());
                }
            });

        }
        return  v;
    }

    private void VideoCheck(String videoURL) {
        if (TextUtils.isEmpty(videoURL)) {
            simpleExoPlayerView.setVisibility(View.GONE);
            //video_err_img.setVisibility(View.VISIBLE);

        } else {
            //video_err_img.setVisibility(View.GONE);
            simpleExoPlayerView.setVisibility(View.VISIBLE);
            player.prepare(getMediaSource(getContext(), Uri.parse(steps.get(position).getVideoURL())));

        }
    }

    public int passPosition() {
        return position;
    }*/

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("description", description);
        outState.putBoolean("ready", playWhenReady);
        outState.putInt("window", exoPlayer.getCurrentWindowIndex());
        outState.putLong("position", exoPlayer.getContentPosition());
        outState.putParcelable("uri", videoUri);


    }
}
    /*@Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }



    @NonNull
    public static MediaSource getMediaSource(Context context, Uri videoUri) {
        DefaultBandwidthMeter bandwidthMeter1 = new DefaultBandwidthMeter();
        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(context,
                Util.getUserAgent(context, "yourApplicationName"), bandwidthMeter1);
        return new ExtractorMediaSource.Factory(dataSourceFactory).createMediaSource(videoUri);
    }
    @NonNull
    public static SimpleExoPlayer getSimpleExoPlayer(Context context) {
        BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
        TrackSelection.Factory videoTrackSelectionFactory = new AdaptiveTrackSelection.Factory(bandwidthMeter);
        DefaultTrackSelector trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);
        return ExoPlayerFactory.newSimpleInstance(context, trackSelector);
    }

}*/
