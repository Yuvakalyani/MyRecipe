package com.example.yuva.myrecipie.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.yuva.myrecipie.data.Step;

import java.util.List;

public class StepAdapter extends RecyclerView.Adapter<StepAdapter.StepHolder> {
    Context context;
    List<Step> steps;
    ClickListener listener;
    public StepAdapter(Context context, List<Step> steps,ClickListener listener) {
        this.context = context;
        this.steps = steps;
        this.listener = listener;
    }
    public interface ClickListener{
        void onClickListener(int position);
    }
    @NonNull
    @Override
    public StepAdapter.StepHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.stepsitem,viewGroup,false);
        return new StepHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull StepAdapter.StepHolder stepHolder, int i) {
        stepHolder.tv.setText(steps.get(i).getShortDescription());
    }

    @Override
    public int getItemCount() {
        return steps.size();
    }

    public class StepHolder extends RecyclerView.ViewHolder {
        TextView tv;
        public StepHolder(@NonNull View itemView) {
            super(itemView);
            tv=itemView.findViewById(R.id.short_des);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClickListener(getAdapterPosition());
                }
            });
        }
    }
}
