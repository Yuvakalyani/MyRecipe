package com.example.yuva.myrecipie;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.yuva.myrecipie.adapter.RecipeAdapter;
import com.example.yuva.myrecipie.data.JsonRecipe;
import com.example.yuva.myrecipie.servicepath.BaseUrl;
import com.example.yuva.myrecipie.servicepath.RetrofitPath;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BaseUrl baseUrl = new BaseUrl();
        RetrofitPath retrofitPath = baseUrl.getRetrofit().create(RetrofitPath.class);
        rv = findViewById(R.id.main_recycler_view);

        Call<List<JsonRecipe>> call = retrofitPath.getRecipes();
        call.enqueue(new Callback<List<JsonRecipe>>() {
            @Override
            public void onResponse(Call<List<JsonRecipe>> call, Response<List<JsonRecipe>> response) {
                List<JsonRecipe> list = response.body();
                rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                rv.setAdapter(new RecipeAdapter(MainActivity.this, list));
                rv.setHasFixedSize(true);
            }

            @Override
            public void onFailure(Call<List<JsonRecipe>> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Unable to fetch data", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
