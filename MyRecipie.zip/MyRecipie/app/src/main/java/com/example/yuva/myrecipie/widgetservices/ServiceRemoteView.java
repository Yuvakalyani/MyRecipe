package com.example.yuva.myrecipie.widgetservices;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.yuva.myrecipie.data.Ingredient;

import java.util.List;

import static com.example.yuva.myrecipie.RecipeAppWidget.ingredients;

public class ServiceRemoteView implements RemoteViewsService.RemoteViewsFactory {
    List<Ingredient> in;
    Context context;

    public ServiceRemoteView(Context c, Intent intent) {
        this.context = c;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {
        in = ingredients;
    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        if (in == null)
            return 0;
        else
            return in.size();
    }

    @Override
    public RemoteViews getViewAt(int position) {
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.listlayout);
        rv.setTextViewText(R.id.text, in.get(position).getIngredient());
        /*Intent intent=new Intent();
        rv.setOnClickFillInIntent(R.id.listview,intent);*/
        return rv;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }
}
